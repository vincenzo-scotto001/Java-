public class BookArray {

   
   public static void main(String[] args) 
   {
       // TODO Auto-generated method stub
       Book b[] = new Book[10];
       Fiction f1 = new Fiction("Finction Book1");
       Fiction f2 = new Fiction("Finction Book2");
       Fiction f3 = new Fiction("Finction Book3");
       Fiction f4 = new Fiction("Finction Book4");
       Fiction f5 = new Fiction("Finction Book5");
       NonFiction n1 = new NonFiction("NonFinction Book1");
       NonFiction n2 = new NonFiction("NonFinction Book2");
       NonFiction n3 = new NonFiction("NonFinction Book3");
       NonFiction n4 = new NonFiction("NonFinction Book4");
       NonFiction n5 = new NonFiction("NonFinction Book5");
       b[0] = f1;
       b[1] = f2;
       b[2] = f3;
       b[3] = f4;
       b[4] = f5;
       b[5] = n1;
       b[6] = n2;
       b[7] = n3;
       b[8] = n4;
       b[9] = n5;
       for(int i=0 ;i<b.length; i++)
       {
           Book a = b[i];
           System.out.println("Title : "+a.getTitle()+ " Cost : "+a.getCost());
       }
   }

}

