public class NonFiction extends Book{
   double cost;
   public NonFiction(String title){
       super(title);
       setCost();
   }
   public void setCost(){
       super.cost = 37.99;
   }
}