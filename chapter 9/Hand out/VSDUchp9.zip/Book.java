public abstract class Book 
{
   public String title;
   public double cost;
   public Book(String title)
   {
       this.title = title;
   }
   public String getTitle() 
   {
       return title;
   }
   public void setTitle(String title) 
   {
       this.title = title;
   }
   public double getCost() 
   {
       return cost;
   }
   public abstract void setCost();
}



