public class Fiction extends Book
{
   public Fiction(String title)
   {
       super(title);
       setCost();
   }
   public void setCost()
   {
       super.cost = 24.99;
   }
}