public class UseBook 
{

   
   public static void main(String[] args) 
   {
       // TODO Auto-generated method stub
       Fiction f = new Fiction("Fiction Book");
       System.out.println("Displaying Fiction Book Detials....");
       System.out.println("Title : "+f.getTitle()+ " Cost : "+f.getCost());
       NonFiction n = new NonFiction("NonFiction Book");
       System.out.println("Displaying NonFiction Book Detials....");
       System.out.println("Title : "+n.getTitle()+ " Cost : "+n.getCost());      
   }

}