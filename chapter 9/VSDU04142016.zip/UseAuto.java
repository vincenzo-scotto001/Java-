// Vincenzo Scotto Di Uccio Hand out problem 3
import java.io.*;
public class UseAuto

{

     public static void main(String args[]) throws Exception

     {

          Ford aford = new Ford();

          aford.print();

          Chevy achevy = new Chevy();

          achevy.print();

     }

}