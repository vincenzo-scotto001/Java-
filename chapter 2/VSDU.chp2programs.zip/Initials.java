// Vincenzo Scotto Di Uccio Chapter 2 program 2

public class Initials

{
   public static void main(String[] args)
   
   {
      String firstName;
      String middleName;
      String lastName;
      char firstInitial;
      char middleInitial;
      char lastInitial;
      
      firstName = "Vincenzo";
      middleName = "Giuseppe";
      lastName = "Scotto Di Uccio";
      firstInitial = 'V';
      middleInitial = 'G';
      lastInitial = 'S';
      
      System.out.println(firstName + "\n" + middleName + "\n" + lastName + "\n" + firstInitial+"\n" + middleInitial+ "\n"+ lastInitial);
    }  
}      