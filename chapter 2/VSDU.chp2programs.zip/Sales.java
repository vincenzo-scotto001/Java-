// Vincenzo Scotto Di Uccio Chapter 2 Program 6

import java.util.*;
public class Sales
{
   public static void main(String[] args)
   {
      double tSales = 8300000;
      double eastCoastSales;
      
      eastCoastSales = tSales *.62;
      
      System.out.println("East Coast Sales prediction: $" + eastCoastSales);
   }
}